<section class="top-bar">
		<div class="container">

			<div class="left-text pull-left">
				<p><span>Reg Office: </span> E-10, Daksha Vhidhaa, IOB Colony, Coimbatore-641046</p>
			</div> <!-- /.left-text -->

			<div class="social-icons pull-right">
				<ul>
					<li><a href="#"><p><span>E-mail: bharathnhrc@gmail.com, contact@nhrcglobal.org<span></p></a></li>
					
				</ul>
			</div> <!-- /.social-icons -->
		</div>
	</section> <!-- /.top-bar -->

	<header class="header">
		<div class="container">
			<div class="logo pull-left">
				<a href="index.php">
					<img src="img//logo2.png" alt="Awesome Image"/>
				</a>
			</div>
			<div class="header-right-info pull-right clearfix">
				
				<div class="single-header-info">
					<div class="icon-box">
						<div class="inner-box">
							<i class="flaticon-telephone"></i>
						</div>
					</div>
					<div class="content">
						<h3>Call Now</h3>
						<p><b>+91 97500 66066 <br>+91 91645 29220<br>+91 97402 55519</b></p>
					</div>
				</div>
				
			</div>
		</div>
	</header> <!-- /.header -->


	<nav class="mainmenu-area stricky">
		<div class="container">
			<div class="navigation pull-left">
				<div class="nav-header">
					<ul>
						<li><a href="index.php">Home</a></li>
						<li><a href="about.php">About us</a></li>
						<li><a href="application.php">Application</a></li>
						<li><a href="nationalcommittee.php">National Committee</a></li>
						<li><a href="wing.php">Wing</a></li>						
						<li><a href="advcommittee.php">Advisory Board</a></li>
						<li><a href="gallery.php">Gallery</a></li>
					</ul>
				</div>
				<div class="nav-footer">
					<button><i class="fa fa-bars"></i></button>
				</div>
			</div>
			
		</div>
	</nav> 