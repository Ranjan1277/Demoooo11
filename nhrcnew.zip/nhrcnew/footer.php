<footer class="footer sec-padding">
		<div class="container">
			<div class="row">
				<div class="col-md-5 col-sm-6">
					<div class="footer-widget about-widget">
						<a href="#">
							<img src="img/logo2.png" alt="Awesome Image"/>
						</a>
						
						<ul class="contact">
							<li><i class="fa fa-map-marker"></i> <span>Reg Office: E- 10, Daksha Vhidhaa,IOB Colony, Coimbatore-641046
</span></li>


<li><i class="fa fa-map-marker"></i> <span>Head Office: 186B,Hari nagar Ashram, New Delhi-110014
</span></li>



 
							
						</ul>
						
					</div>
				</div>
				<div class="col-md-2 col-sm-6">
					<div class="footer-widget quick-links">
						<h3 class="title">Pages</h3>
						<ul>
							<li><a href="about.php">About Us</a></li>
							<li><a href="application.php">Application</a></li>
							<li><a href="nationalcommittee.php">National Committee</a></li>
							
							
						</ul>
					</div>
				</div>
				<div class="col-md-2 col-sm-6">
					<div class="footer-widget quick-links">
						<h3 class="title">Pages</h3>
						<ul>
							
							<li><a href="wing.php">Wing</a></li>						
						<li><a href="advcommittee.php">Advisory Board</a></li>
						<li><a href="gallery.php">Gallery</a></li>
						
												
						
						
						
						
						<li><a href="contact.php">Contact</a></li>
						</ul>
					</div>
				</div>



				<div class="col-md-3 col-sm-6">
					<div class="footer-widget about-widget">
						<h3 class="title">Contact</h3>
						
						<ul class="contact">
						<li><i class="fa fa-phone"></i> <span>+91 9750066066, +91 9164529220 , +919740255519</span></li>
							<li><i class="fa fa-envelope-o"></i> <span>bharathnhrc@gmail.com , contact@nhrcglobal.org</span></li>	



 
							
						</ul>
						<ul class="social">
							<li><a href="#"><i class="fa fa-facebook"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter"></i></a></li>
							
							<li><a href="#"><i class="fa fa-youtube"></i></a></li>
						</ul>
					</div>
				</div>


				
				
			</div>
		</div>
	</footer>

	<section class="footer-bottom">
		<div class="container text-center">
			<p>Developed By MTG Techsoft </p>
		</div>
	</section>